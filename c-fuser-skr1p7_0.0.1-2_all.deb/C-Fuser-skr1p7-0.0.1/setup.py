import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="C-Fuser-skr1p7", # Replace with your own username
    version="0.0.1",
    author="skr1p7",
    author_email="a.gautam201@gmail.com",
    description="A Python application",
    long_description="Using Codeforces API to get username details" ,
    url="https://github.com/skr1p7/C-Fuser.git",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved ::GNU GPLv3",
        "Operating System :: Debian",
    ],
    python_requires='>=3.6',
)
